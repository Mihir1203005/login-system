import React from 'react'

const Home = () => {
  return (
    <div>
      <img src="https://paintingpractice.com/wp-content/uploads/2023/03/NIKE_THUMBNAIL_STILL.jpg" className='bg' alt="" />
    </div>
  )
}

export default Home
